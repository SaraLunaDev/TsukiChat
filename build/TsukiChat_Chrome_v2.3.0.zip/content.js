(function() {
    'use strict';
    if (!(window.location.href.includes('live_chat') || window !== window.top || document.querySelector('yt-live-chat-app'))) return;
    let backgroundEnabled = true;
    let colorAdjustEnabled = false;
    let fontSize = 14;
    
    chrome.storage.sync.get(['backgroundEnabled', 'colorAdjustEnabled', 'fontSize'], (result) => {
        backgroundEnabled = result.backgroundEnabled !== false;
        colorAdjustEnabled = result.colorAdjustEnabled === true;
        fontSize = result.fontSize || 14;
        updateBackgroundStyles();
        updateFontSize();
    });
    
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'toggleBackground') {
            backgroundEnabled = message.enabled;
            updateBackgroundStyles();
            sendResponse({ success: true });
        } else if (message.action === 'toggleColorAdjust') {
            colorAdjustEnabled = message.enabled;
            reapplyColorAdjustment();
            sendResponse({ success: true });
        } else if (message.action === 'updateFontSize') {
            fontSize = message.fontSize;
            updateFontSize();
            sendResponse({ success: true });
        }
        return true;
    });
    
    // Función para ajustar colores automáticamente
    const adjustColor = (hexColor) => {
        if (!colorAdjustEnabled) return hexColor;
        
        // Convertir hex a RGB
        const r = parseInt(hexColor.slice(1, 3), 16);
        const g = parseInt(hexColor.slice(3, 5), 16);
        const b = parseInt(hexColor.slice(5, 7), 16);
        
        // Convertir RGB a HSL para preservar el matiz
        const max = Math.max(r, g, b) / 255;
        const min = Math.min(r, g, b) / 255;
        const diff = max - min;
        const add = max + min;
        const l = add * 0.5;
        
        let h;
        if (diff === 0) {
            h = 0; // Gris
        } else {
            switch (max) {
                case r / 255: h = ((g - b) / 255) / diff + (g < b ? 6 : 0); break;
                case g / 255: h = ((b - r) / 255) / diff + 2; break;
                case b / 255: h = ((r - g) / 255) / diff + 4; break;
            }
            h /= 6;
        }
        
        // Fijar saturación y luminosidad para legibilidad universal
        const fixedSaturation = 0.9; // 90% saturación para colores muy vibrantes
        const fixedLightness = 0.45; // 45% luminosidad - legible en ambos fondos
        
        // Convertir HSL fijo de vuelta a RGB
        const hue2rgb = (p, q, t) => {
            if (t < 0) t += 1;
            if (t > 1) t -= 1;
            if (t < 1/6) return p + (q - p) * 6 * t;
            if (t < 1/2) return q;
            if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
            return p;
        };
        
        let newR, newG, newB;
        const q = fixedLightness < 0.5 ? fixedLightness * (1 + fixedSaturation) : fixedLightness + fixedSaturation - fixedLightness * fixedSaturation;
        const p = 2 * fixedLightness - q;
        newR = hue2rgb(p, q, h + 1/3);
        newG = hue2rgb(p, q, h);
        newB = hue2rgb(p, q, h - 1/3);
        
        // Convertir de vuelta a hex
        const toHex = (val) => Math.round(val * 255).toString(16).padStart(2, '0');
        return `#${toHex(newR)}${toHex(newG)}${toHex(newB)}`;
    };
    
    const updateFontSize = () => {
        let fontStyleElement = document.getElementById('tsuki-font-styles');
        if (fontStyleElement) {
            fontStyleElement.remove();
        }
        
        fontStyleElement = document.createElement('style');
        fontStyleElement.id = 'tsuki-font-styles';
        fontStyleElement.textContent = `
            yt-live-chat-text-message-renderer[data-tsuki-processed="true"] #message,
            yt-live-chat-text-message-renderer[data-tsuki-processed="true"] #author-name,
            yt-live-chat-text-message-renderer[data-tsuki-processed="true"] yt-live-chat-author-chip span,
            yt-live-chat-text-message-renderer[data-tsuki-event="true"] .tsuki-event-username,
            yt-live-chat-text-message-renderer[data-tsuki-event="true"] .tsuki-event-data {
                font-size: ${fontSize}px !important;
            }
        `;
        document.head.appendChild(fontStyleElement);
    };
    
    const reapplyColorAdjustment = () => {
        // Reaplica el ajuste de colores a todos los mensajes ya procesados
        document.querySelectorAll('yt-live-chat-text-message-renderer[data-tsuki-processed="true"]:not([data-tsuki-event])').forEach(message => {
            const messageElement = message.querySelector('#message');
            if (!messageElement) return;
            
            // Buscar el color original almacenado
            const originalColor = message.dataset.originalColor;
            if (!originalColor) return;
            
            const adjustedColor = adjustColor(originalColor);
            
            const authorNameElement = message.querySelector('#author-name');
            if (authorNameElement) {
                authorNameElement.style.setProperty('color', adjustedColor, 'important');
            }
            
            const nameSpan = message.querySelector('yt-live-chat-author-chip span[dir="auto"]');
            const authorChip = message.querySelector('yt-live-chat-author-chip');
            if (nameSpan) {
                nameSpan.style.setProperty('color', adjustedColor, 'important');
                if (authorChip) {
                    authorChip.style.setProperty('color', adjustedColor, 'important');
                }
            }
        });
    };
    
    const applyColorToMessage = (message, originalColor) => {
        const adjustedColor = adjustColor(originalColor);
        
        const authorNameElement = message.querySelector('#author-name');
        if (authorNameElement) {
            authorNameElement.style.setProperty('color', adjustedColor, 'important');
        }
        
        const nameSpan = message.querySelector('yt-live-chat-author-chip span[dir="auto"]');
        const authorChip = message.querySelector('yt-live-chat-author-chip');
        if (nameSpan) {
            nameSpan.style.setProperty('color', adjustedColor, 'important');
            if (authorChip) {
                authorChip.style.setProperty('color', adjustedColor, 'important');
            }
        }
    };
    
    const updateBackgroundStyles = () => {
        let styleElement = document.getElementById('tsuki-background-styles');
        if (styleElement) {
            styleElement.remove();
        }
        
        if (backgroundEnabled) {
            styleElement = document.createElement('style');
            styleElement.id = 'tsuki-background-styles';
            styleElement.textContent = `
                yt-live-chat-text-message-renderer[data-tsuki-processed="true"]:not([data-tsuki-event]):nth-child(odd) {
                    background-color: rgba(255, 255, 255, 0.05) !important;
                }
                yt-live-chat-text-message-renderer[data-tsuki-processed="true"]:not([data-tsuki-event]):nth-child(even) {
                    background-color: transparent !important;
                }
            `;
            document.head.appendChild(styleElement);
        } else {
            styleElement = document.createElement('style');
            styleElement.id = 'tsuki-background-styles';
            styleElement.textContent = `
                yt-live-chat-text-message-renderer[data-tsuki-processed="true"]:not([data-tsuki-event]) {
                    background-color: transparent !important;
                }
            `;
            document.head.appendChild(styleElement);
        }
    };
    
    const processMessage = message => {
        if (message.dataset.tsukiProcessed) return;
        
        const messageElement = message.querySelector('#message');
        if (!messageElement) return;
        
        const messageText = messageElement.textContent.trim();
        
        // Verificar formato de evento: bit_[usuario][mensaje x## datos] o sub_[usuario][mensaje x## datos]
        const eventMatch = messageText.match(/^(\w+)_\[([^\]]+)\]\[(.+)\]$/);
        if (eventMatch) {
            const [, eventType, username, eventData] = eventMatch;
            
            // Buscar multiplicador en el mensaje
            const multiplierMatch = eventData.match(/(.+?)\s(x\d+)\s(.+)/);
            let eventText, multiplier, additionalText;
            
            if (multiplierMatch) {
                [, eventText, multiplier, additionalText] = multiplierMatch;
            } else {
                eventText = eventData;
                multiplier = '';
                additionalText = '';
            }
            
            message.dataset.tsukiProcessed = 'true';
            message.dataset.tsukiEvent = 'true';
            
            // Crear contenedor del evento
            const eventContainer = document.createElement('div');
            eventContainer.className = 'tsuki-event-container';
            
            // Crear elemento del nombre de usuario
            const usernameElement = document.createElement('div');
            usernameElement.className = 'tsuki-event-username';
            usernameElement.textContent = username + ':';
            
            // Crear elemento de datos del evento
            const dataElement = document.createElement('div');
            dataElement.className = 'tsuki-event-data';
            
            // Separar el multiplicador del resto de los datos
            const multiplierElement = document.createElement('span');
            multiplierElement.className = 'tsuki-event-multiplier';
            multiplierElement.textContent = multiplier;
            
            if (multiplier) {
                dataElement.textContent = eventText + ' ';
                dataElement.appendChild(multiplierElement);
                if (additionalText) {
                    dataElement.appendChild(document.createTextNode(' ' + additionalText));
                }
                multiplierElement.textContent = multiplier;
            } else {
                dataElement.textContent = eventData;
            }
            
            eventContainer.appendChild(usernameElement);
            eventContainer.appendChild(dataElement);
            
            // Reemplazar contenido del mensaje
            messageElement.innerHTML = '';
            messageElement.appendChild(eventContainer);
            
            // Intentar cargar icono del evento
            const iconUrl = chrome.runtime.getURL(`events/${eventType}.svg`);
            const iconElement = document.createElement('div');
            iconElement.className = 'tsuki-event-icon';
            
            const img = document.createElement('img');
            img.src = iconUrl;
            img.onerror = function() {
                // Si no existe el icono, mantener el timestamp original
                iconElement.style.display = 'none';
                const timestampElement = message.querySelector('#timestamp');
                if (timestampElement) {
                    timestampElement.style.display = 'block';
                }
            };
            img.onload = function() {
                // Si el icono existe, ocultar el timestamp
                const timestampElement = message.querySelector('#timestamp');
                if (timestampElement) {
                    timestampElement.style.display = 'none';
                }
            };
            
            iconElement.appendChild(img);
            
            // Insertar el icono antes del contenedor del evento
            const contentElement = message.querySelector('#content');
            if (contentElement) {
                contentElement.insertBefore(iconElement, messageElement);
            }
            
            // Ocultar elementos no necesarios
            const authorNameElement = message.querySelector('#author-name');
            if (authorNameElement) authorNameElement.style.display = 'none';
            
            const authorChip = message.querySelector('yt-live-chat-author-chip');
            if (authorChip) authorChip.style.display = 'none';
            
            const authorPhoto = message.querySelector('#author-photo');
            if (authorPhoto) authorPhoto.style.display = 'none';
            
            return;
        }
        
        // Formato normal: #HEX[username]message
        const match = messageText.match(/^#([A-Fa-f0-9]{6})\[([^\]]+)\](.*)$/);
        
        if (!match) return;
        
        const [, colorHex, extractedUsername, cleanMessage] = match;
        const originalColor = '#' + colorHex;
        
        message.dataset.tsukiProcessed = 'true';
        message.dataset.originalColor = originalColor; // Almacenar color original
        
        // Aplicar color ajustado
        applyColorToMessage(message, originalColor);
        
        const authorNameElement = message.querySelector('#author-name');
        if (authorNameElement) {
            authorNameElement.textContent = extractedUsername + ':';
        }
        
        const nameSpan = message.querySelector('yt-live-chat-author-chip span[dir="auto"]');
        if (nameSpan) {
            nameSpan.textContent = extractedUsername + ':';
        }
        
        messageElement.textContent = cleanMessage.trim();
        
        const authorPhoto = message.querySelector('#author-photo');
        if (authorPhoto) authorPhoto.style.display = 'none';
    };
    
    const processAllMessages = () => {
        document.querySelectorAll('yt-live-chat-text-message-renderer:not([data-tsuki-processed])').forEach(processMessage);
    };
    
    processAllMessages();
    
    const observer = new MutationObserver(mutations => {
        for (const mutation of mutations) {
            if (mutation.type === 'childList') {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1) {
                        if (node.tagName === 'YT-LIVE-CHAT-TEXT-MESSAGE-RENDERER') {
                            processMessage(node);
                        } else if (node.querySelector) {
                            node.querySelectorAll('yt-live-chat-text-message-renderer:not([data-tsuki-processed])').forEach(processMessage);
                        }
                    }
                }
            }
        }
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
    
})();